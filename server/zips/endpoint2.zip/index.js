"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const response_1 = require("../shared/response");
const handler = async (event) => {
    return (0, response_1.ok)({
        endpoint: 'endpoint2',
        method: event.httpMethod,
        message: 'Create New User — action permitted',
        requiredScope: 'myapi/write',
        timestamp: new Date().toISOString(),
        requestId: event.requestContext.requestId,
    });
};
exports.handler = handler;

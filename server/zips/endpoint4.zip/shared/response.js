"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ok = ok;
exports.error = error;
const cors_1 = require("./cors");
function ok(body) {
    return {
        statusCode: 200,
        headers: cors_1.CORS_HEADERS,
        body: JSON.stringify({ success: true, ...body }),
    };
}
function error(statusCode, message) {
    return {
        statusCode,
        headers: cors_1.CORS_HEADERS,
        body: JSON.stringify({ success: false, message }),
    };
}

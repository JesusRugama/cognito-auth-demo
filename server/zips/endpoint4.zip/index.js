"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const response_1 = require("../shared/response");
const handler = async (event) => {
    return (0, response_1.ok)({
        endpoint: 'endpoint4',
        method: event.httpMethod,
        message: 'Delete Record — action permitted',
        requiredScope: 'myapi/admin',
        timestamp: new Date().toISOString(),
        requestId: event.requestContext.requestId,
    });
};
exports.handler = handler;

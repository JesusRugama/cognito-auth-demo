"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const response_1 = require("../shared/response");
const handler = async (event) => {
    return (0, response_1.ok)({
        endpoint: 'endpoint1',
        method: event.httpMethod,
        message: 'Read Users List — action permitted',
        requiredScope: 'myapi/read',
        timestamp: new Date().toISOString(),
        requestId: event.requestContext.requestId,
    });
};
exports.handler = handler;
